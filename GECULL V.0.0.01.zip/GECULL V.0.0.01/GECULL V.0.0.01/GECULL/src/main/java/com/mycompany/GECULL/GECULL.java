/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.GECULL;

import com.mycompany.GECULL.Display.FormularioLogin;

/**
 *
 * @author crism
 */
public class GECULL{

    public static void main(String[] args) {
        FormularioLogin Login = new FormularioLogin();
               
        Login.setVisible(true);
    }
}
